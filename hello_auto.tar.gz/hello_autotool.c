#include <stdio.h>


int main (){
	
	printf("HELLO! This Is an AUTOTOOL BUILD\n");

return 0;
}
